### 02_settings
Contains variables and settings for your project and to override any defaults from `01_utils/`.
This folder should not output any CSS when compiled on its own.